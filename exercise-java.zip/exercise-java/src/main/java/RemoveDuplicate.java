import java.util.Scanner;

public class RemoveDuplicate {

    public static String removeDuplicates(String input) {
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);

            // If char not exit --> add
            if (result.indexOf(String.valueOf(c)) == -1) {
                result.append(c);
            }
        }

        return result.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nhập câu: ");
        String input = scanner.nextLine();

        String output = removeDuplicates(input);

        System.out.println("Kết quả: " + output);

        scanner.close();
    }
}