import java.util.Scanner;

public class SecondLargest {

    public static int findSecondLargest(int[] arr) {
        // Nếu mảng có ít hơn 2 phần tử
        if (arr == null || arr.length < 2) {
            return Integer.MIN_VALUE;
        }

        int max1 = Integer.MIN_VALUE;
        int max2 = Integer.MIN_VALUE;

        for (int i = 0; i < arr.length; i++) {

            if (arr[i] > max1) {
                max2 = max1;
                max1 = arr[i];
            }
            else if (arr[i] > max2 && arr[i] != max1) {
                max2 = arr[i];
            }
        }

        return max2;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập số phần tử
        System.out.print("Nhập số phần tử: ");
        int n = scanner.nextInt();

        // Khai báo mảng
        int[] arr = new int[n];

        // Nhập từng phần tử
        System.out.println("Nhập các phần tử:");
        for (int i = 0; i < n; i++) {
            System.out.print("arr[" + i + "] = ");
            arr[i] = scanner.nextInt();
        }

        // Gọi hàm tìm số lớn thứ hai
        int result = findSecondLargest(arr);

        // In kết quả
        if (result == Integer.MIN_VALUE) {
            System.out.println("Không đủ phần tử để tìm!");
        } else {
            System.out.println("Giá trị lớn thứ hai: " + result);
        }

        scanner.close();
    }
}