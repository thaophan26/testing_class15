import java.util.Scanner;

public class SumEvenNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập số phần tử
        System.out.print("Nhập số phần tử: ");
        int n = scanner.nextInt();
        int[] arr = new int[n];
        int total = 0;
        for (int i = 0; i <= n; i++) {
            if (i%2==0) {
                total = total + i;
            }
        }

        System.out.print("Tổng các số chẵn: " + total);
    }
}
