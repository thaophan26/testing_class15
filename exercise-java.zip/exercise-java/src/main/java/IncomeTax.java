import java.util.Scanner;

public class IncomeTax {
    public static double caculateTax (double income) {
        double tax = 0;
        if (0 < income && income < 5_000_000) {
            tax += income * 0.05;
        }
        if (5_000_001 < income && income < 10_000_000) {
            tax += income * 0.1;
        }
        if (10_000_001 < income && income < 18_000_000) {
            tax += income * 0.15;
        }
        if (18_000_001 < income && income < 32_000_000) {
            tax += income * 0.2;
        }
        if (32_000_001 < income && income < 52_000_000) {
            tax += income * 0.25;
        }
        if (52_000_001 < income && income < 80_000_000) {
            tax += income * 0.3;
        }
        if (income > 80_000_001) {
            tax += income * 0.25;
        }
        return tax;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nhập lương của bạn trong năm qua (đơn vị VNĐ): ");
        double income = scanner.nextInt();
        double tax = caculateTax (income);

        System.out.println("Thuế ba cần phải trả là: " + tax);

        scanner.close();
    }
}
