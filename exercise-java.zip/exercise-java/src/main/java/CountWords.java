import java.util.Scanner;

public class CountWords {
    public static int countWords(String input) {
        int count = 0;
        boolean inWord = false;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);

            if (c != ' ' && !inWord) {
                count++;        // bắt đầu từ mới
                inWord = true;
            } else if (c == ' ') {
                inWord = false; // gặp khoảng trắng → kết thúc từ
            }
        }
        return count;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nhập câu: ");
        String input = scanner.nextLine();

        int result = countWords(input);

        System.out.println("Số chữ: " + result);

        scanner.close();
    }
}
