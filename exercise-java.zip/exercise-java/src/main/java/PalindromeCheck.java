import java.util.Scanner;

public class PalindromeCheck {

    public static boolean isPalindrome(String input) {
        int left = 0;
        int right = input.length() - 1;

        while (left < right) {
            if (input.charAt(left) != input.charAt(right)) {
                return false; // lệch
            }
            left++;
            right--;
        }

        return true; // đối xứng
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nhập từ cần so sánh: ");
        String input = scanner.nextLine();
        if (isPalindrome(input))
        {
            System.out.println("Đây là một từ đối xứng");
        }
        else
        {
            System.out.println("Đây là một từ không đối xứng");
        }

        scanner.close();
    }
}