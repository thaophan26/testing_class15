import java.util.Scanner;

public class RemoveVowels {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //input string
        System.out.print("Nhap chuoi: ");
        String input = scanner.nextLine();

        //declare an array of vowels.
        char[] vowels = {'a', 'e', 'i', 'o', 'u',
                'A', 'E', 'I', 'O', 'U'};

        //declare a new string
        StringBuilder result = new StringBuilder();

        //character browsing
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            boolean isVowel = false;

            //check if c is in the array of vowels.
            for (int j = 0; j < vowels.length; j++) {
                if (c == vowels[j]) {
                    isVowel = true;
                    break; // tìm thấy rồi thì dừng
                }
            }
        //If it's not a vowel, keep it
        if (!isVowel) {
            result.append(c);
        }
    }

    //print result
        System.out.println("Chuoi sau khi da xoa cac nguyen am: " + result);

        scanner.close();
    }
}
