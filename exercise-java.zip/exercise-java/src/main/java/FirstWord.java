import java.util.Scanner;

public class FirstWord {
    public static String getFirstLetters(String input) {
        StringBuilder result = new StringBuilder();
        boolean isNewWord = true;

        for (int i = 0; i <input.length(); i++) {
            char c = input.charAt(i);
            if (c != ' ' && isNewWord) {
                result.append(Character.toUpperCase(c)); // Upper
                result.append(' '); // add space
                isNewWord = false;
            }
            else if (c == ' ') {
                isNewWord = true;   // new word
            }
        }
        return result.toString();
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nhập câu: ");
        String input = scanner.nextLine();

        String result = getFirstLetters(input);

        System.out.println("Kết quả: " + result);

        scanner.close();
    }
}
