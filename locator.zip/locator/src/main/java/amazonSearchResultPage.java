import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class amazonSearchResultPage {
    public static <WebElement> void main(String[] args) {

        WebDriver driver = new ChromeDriver();

        driver.get("");

        // Tìm element result
        WebElement resultText = driver.findElement(
                By.xpath("//span[contains(.,'results for')]")
        );
    }
}
