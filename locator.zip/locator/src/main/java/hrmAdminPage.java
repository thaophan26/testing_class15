import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class hrmAdminPage {
    public static <WebElement> void main(String[] args) {

        WebDriver driver = new ChromeDriver();

        driver.get("");

        // Tìm element chứa chữ Admin
        WebElement adminMenu = driver.findElement(
                By.xpath("//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name' and text()='Admin']")
        );
        // Tìm element chứa chữ PIM
        WebElement pimMenu = driver.findElement(
                By.xpath("//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name' and text()='PIM']")
        );
        // Tìm element chứa chữ Leave
        WebElement leaveMenu = driver.findElement(
                By.xpath("//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name' and text()='Leave']")
        );
        // Tìm element  nhập username
        WebElement usernameInput = driver.findElement(
                By.xpath("//label[text()='Username']/ancestor::div[contains(@class,'oxd-input-group')]//input[@class='oxd-input oxd-input--active']")
        );
        // Tìm element chứa dropdownlist User role
        WebElement userRoleDropdown = driver.findElement(
                By.xpath("//label[text()='User Role']/ancestor::div[contains(@class,'oxd-input-group')]//div[@class='oxd-select-text-input']")
        );
        WebElement userRoleAdmin = driver.findElement(
                By.xpath("//div[@class='oxd-select-text-input' and text()='Admin']")
        );
        WebElement userRoleESS = driver.findElement(
                By.xpath("//div[@class='oxd-select-text-input' and text()='ESS']")
        );
        // Tìm element nhập Employ Name
        WebElement emplName = driver.findElement(
                By.xpath("//div[@class='oxd-autocomplete-text-input--before' ]/following::input[@placeholder='Type for hints...']")
        );
        // Tìm element button Reset
        WebElement resetButton = driver.findElement(
                By.xpath("//button[@type='button' and text()=' Reset ']")
        );
        // Tìm element button Reset
        WebElement searchButton = driver.findElement(
                By.xpath("//button[@type='submit' and text()=' Search ']")
        );
        // Tìm element tab user management
        WebElement managementTab = driver.findElement(
                By.xpath("//span[@class='oxd-topbar-body-nav-tab-item' and text()='User Management ']")
        );

        // Tìm element tab user management
        WebElement userTable = driver.findElement(
                By.xpath("//div[@class='oxd-table-cell oxd-padding-cell']//div[text()='FMLName']")
        );
        // Tìm element tab user role
        WebElement roleTable = driver.findElement(
                By.xpath("//div[text()='FMLName']//parent::div[@class='oxd-table-cell oxd-padding-cell']//following-sibling::div[@class='oxd-table-cell oxd-padding-cell']//div[text()='ESS']")
        );

        // Tìm element bin trash của user Admin
        WebElement trashIcon = driver.findElement(
                By.xpath("//div[@role='row' and .//div[@role='cell'][2]//div[text()='Admin']]//i[@class='oxd-icon bi-trash']")
        );
        // Tìm element bin trash của user Admin
        WebElement editIcon = driver.findElement(
                By.xpath("//div[@role='row' and .//div[@role='cell'][2]//div[text()='Admin']]//i[@class='oxd-icon bi-pencil-fill']")
        );
        // Tìm element của user rolre in table
        WebElement roleTable = driver.findElement(
                By.xpath("//div[@class='oxd-table-header-cell oxd-padding-cell oxd-table-th' and text()='User Role']")
        );
        // Tìm element empl name in table
        WebElement nameTable = driver.findElement(
                By.xpath("//div[@class='oxd-table-header-cell oxd-padding-cell oxd-table-th' and text()='Employee Name']")
        );
        // Tìm element header
        WebElement headerPage = driver.findElement(
                By.xpath("//div[@class='oxd-topbar-header-title']")
        );
        // Tìm element icon thu gọn left
        WebElement iconLefft = driver.findElement(
                By.xpath("//i[@class='oxd-icon bi-chevron-left']")
        );
        // Tìm element button add
        WebElement iconUp = driver.findElement(
                By.xpath("//button[text()=' Add ']")
        );
        driver.quit();
}
