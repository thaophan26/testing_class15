import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class airbnbHomePage {
    public static <WebElement> void main(String[] args) {

        WebDriver driver = new ChromeDriver();

        driver.get("");

        // Tìm element logo cypersoft
        WebElement cyberSoftText = driver.findElement(
                By.xpath("//span[@class='self-center text-2xl font-semi font-bold whitespace-nowrap  text-[#FE6B6E] duration-500 hover:text-rose-600' and text()='CyberSoft']")
        );

        // Tìm element home
        WebElement homeMenu = driver.findElement(
                By.xpath("//a[@aria-current='page' and @href='/' and text()='Home']")
        );

        // Tìm element sbout
        WebElement aboutMenu = driver.findElement(
                By.xpath("//a[@href='/' and text()='About']")
        );

        // Tìm element icon user
        WebElement userIcon = driver.findElement(
                By.xpath("//img[@class='h-10']")
        );

        // Tìm element location block
        WebElement locationBlock = driver.findElement(
                By.xpath("//div[contains(@class,'col-span-3') and .//p[text()='Bạn sắp đi đâu?']]")
        );

        // Tìm element from date - to date
        WebElement deatBlock = driver.findElement(
                By.xpath("//div[contains(@class,'col-span-4')]")
        );

        // Tìm element add cus
        WebElement addCusBlock = driver.findElement(
                By.xpath("//p[text()='Thêm khách']")
        );

        // Tìm element minusButton
        WebElement minusButton = driver.findElement(
                By.xpath("//button[@disabled and .//div[text()='-']]")
        );

        // Tìm element plusButton
        WebElement plusButton = driver.findElement(
                By.xpath("//button[not(@disabled) and .//div[text()='+']]")
        );

        // Tìm element HCL location
        WebElement hoChiMinhCard = driver.findElement(
                By.xpath("//a[@href='/rooms/ho-chi-minh' and .//h2[text()='Hồ Chí Minh']]")
        );

        // Tìm element text Cần thơ
        WebElement canThoTitle = driver.findElement(
                By.xpath("//h2[@class='font-bold' and text()='Cần Thơ']")
        );

        // Tìm element Loại nơi ở
        WebElement locationTypeButton = driver.findElement(
                By.xpath("//button[text()='Loại nơi ở']")
        );

        // Tìm element giờ lái xe
        WebElement canThoDrivingTime = driver.findElement(
                By.xpath("//h2[text()='Cần Thơ']/following-sibling::p")
        );
}
